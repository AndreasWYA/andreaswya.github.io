
import React, { useRef, useState } from 'react'
import { Form, Button, Card, Alert } from 'react-bootstrap'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

export default function ChangeEmail(){
    const emailRef = useRef()
    const { currentUser, updateEmail } = useAuth()
    const [error, setError] = useState('')
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate()

    function handleSubmit(e) {
        e.preventDefault()

        const promises = []
        setLoading(true)
        setError("")

        if(emailRef.current.value !== currentUser.email){
            promises.push(updateEmail(emailRef.current.value))
        }else{
            return setError("Same Email")
        }

        Promise.all(promises).then(()=>{
            navigate('/')
        }).catch(()=>{
            setError("Failed to update Account")
        }).finally(()=>{
            setLoading(false)
        })
      }

    return(
        <>
            <Card>
                <Card.Body>
                    <h2 className='text-center mb-4'>Change Email</h2>
                    {error && <Alert variant="danger">{error}</Alert>}
                    <Form onSubmit={handleSubmit}>
                        <strong>Current Email:</strong> <br/> {currentUser.email}
                        <Form.Group id="email" className='mt-3'>
                            <Form.Label>Email</Form.Label>
                            <Form.Control type="email" ref={emailRef} required/>
                        </Form.Group>
                        <Button disabled={loading} className='w-100 mt-3' type='submit'>Update Email</Button>
                    </Form>
                </Card.Body>
            </Card>
            <div className='w-100 text-center mt-2'><Link to="/user-settings">Cancel</Link></div>
        </>
    )
}