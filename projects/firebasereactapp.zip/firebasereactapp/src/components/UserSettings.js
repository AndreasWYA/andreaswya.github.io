
import React from 'react'
import { Card } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

export default function UserSettings(){
    const { currentUser } = useAuth()

    return(
        <>
            <Card>
                <Card.Body>
                    <h2 className='text-center mb-4'>Update Profile</h2>
                    <table>
                        <tr>
                            <th>Email</th>
                            <th></th>
                        </tr>
                        <tr>
                            <td className=''>{currentUser.email}</td>
                            <td className='' style={{ paddingLeft: '5rem', fontSize: '14px'}}><Link to="/change-email">Change Email</Link></td>
                        </tr>    
                        <br/>       
                        <tr>
                            <th>Password</th>
                            <td style={{ paddingLeft: '3.5rem' , fontSize: '14px' }}><Link to="/change-password">Change Password</Link></td>
                        </tr>
                    </table>
                </Card.Body>
            </Card>
            <div className='w-100 text-center mt-2'><Link to="/">Cancel</Link></div>
        </>
    )
}