import React from "react";
import { Container } from "react-bootstrap";
import { AuthProvider } from "../contexts/AuthContext";
import Signup from "./Signup";
import { HashRouter as Router, Routes, Route } from 'react-router-dom'
import Dashboard from "./Dashboard"
import Login from "./Login"
import PrivateRoute from "./PrivateRoute";
import ForgotPassword from "./ForgotPassword";
import UserSettings from "./UserSettings";
import ChangePassword from "./ChangePassword";
import ChangeEmail from "./ChangeEmail";

function App() {
  return( 
    <AuthProvider>
      <Container className='d-flex align-items-center justify-content-center' style={{minHeight: "100vh"}}>
        <div className="w-100" style={{maxWidth: "400px"}}>
          <Router>
            <AuthProvider>
              <Routes>
                <Route Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>}></Route>
                <Route exact path="/user-settings" element={<PrivateRoute><UserSettings /></PrivateRoute>}></Route>
                <Route exact path="/change-password" element={<PrivateRoute><ChangePassword /></PrivateRoute>}></Route>
                <Route exact path="/change-email" element={<PrivateRoute><ChangeEmail /></PrivateRoute>}></Route>
                <Route path="/signup" element={<Signup />}></Route>
                <Route path="/login" element={<Login />}></Route>
                <Route path="/forgot-password" element={<ForgotPassword />}></Route>
              </Routes>
            </AuthProvider>
          </Router>
        </div>
      </Container>
    </AuthProvider>
  )
}

export default App;
