var username = document.forms["contact"]["username"];
var age = document.forms["contact"]["age"];
var country = document.forms["contact"]["country"];
var comment = document.forms["contact"]["comment"];
var err = document.getElementById('err');

function validateUserName(){
	if(username.value == ""){
		err.innerHTML = "Username must be filled!";
		return false;
	}else if(username.value.match(' ')){
		err.innerHTML = "Username should not have spaces!";
		return false;
	}else{
		err.innerHTML = "";
		return true;
	}
}

function validateAge(){
	if(age.value == ""){
		err.innerHTML = "Age must be filled!";
		return false;
	}else if(age.value.match('-')){
		err.innerHTML = "Age should not be minus!";
		return false;
	}else{
		err.innerHTML = "";
		return true;
	}
}

function validateCountry(){
	if(country.value == ""){
		err.innerHTML = "Choose your country!";
		return false;
	}else{
		err.innerHTML = "";
		return true;
	}
}

function validateComment(){
	if(comment.value == ""){
		err.innerHTML = "Comment must be filled!";
		return false;
	}else{
		err.innerHTML = "";
		return true;
	}
}

function validate(){
	if(!validateUserName())return false;
	if(!validateAge())return false;
	if(!validateCountry())return false;
	if(!validateComment())return false;
	alert("Thank You for your comment!");
}