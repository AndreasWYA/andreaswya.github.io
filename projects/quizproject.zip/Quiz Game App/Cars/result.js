const username = document.getElementById('username');
const saveScoreBtn = document.getElementById('saveScoreBtn');
const finalScore = document.getElementById('finalScore');
const CarsQuizScore = localStorage.getItem('CarsQuizScore');

const highCarsScores = JSON.parse(localStorage.getItem("highCarsScores")) || [];

const MAX_HIGH_SCORES = 10;

finalScore.innerText = CarsQuizScore;

username.addEventListener('keyup', ()=>{
    saveScoreBtn.disabled = !username.value;
})

saveHighScore =(e)=>{
    e.preventDefault();

    const score = {
        score: CarsQuizScore,
        name: username.value
    };
    highCarsScores.push(score);
    highCarsScores.sort((a,b) => b.score - a.score);
    highCarsScores.splice(10);

    localStorage.setItem("highCarsScores", JSON.stringify(highCarsScores));
    window.location.assign('/index.html');
};