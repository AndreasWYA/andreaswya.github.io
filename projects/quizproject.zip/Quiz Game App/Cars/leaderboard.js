const highScoresList = document.getElementById('highScoresList');
const highCarsScores = JSON.parse(localStorage.getItem("highCarsScores")) || [];

highScoresList.innerHTML = highCarsScores
  .map(score => {
    return `<tr><li class="high-score"><td><span id="leaderboardName">${score.name}</span></td><td id="leaderboardScore">${score.score}</td></li></tr>`;
  })
  .join("");