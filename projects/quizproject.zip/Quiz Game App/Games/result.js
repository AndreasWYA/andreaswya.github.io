const username = document.getElementById('username');
const saveScoreBtn = document.getElementById('saveScoreBtn');
const finalScore = document.getElementById('finalScore');
const gamesQuizScore = localStorage.getItem('gamesQuizScore');

const highGamesScores = JSON.parse(localStorage.getItem("highGamesScores")) || [];

const MAX_HIGH_SCORES = 10;

finalScore.innerText = gamesQuizScore;

username.addEventListener('keyup', ()=>{
    saveScoreBtn.disabled = !username.value;
})

saveHighScore =(e)=>{
    e.preventDefault();

    const score = {
        score: gamesQuizScore,
        name: username.value
    };
    highGamesScores.push(score);
    highGamesScores.sort((a,b) => b.score - a.score);
    highGamesScores.splice(10);

    localStorage.setItem("highGamesScores", JSON.stringify(highGamesScores));
    window.location.assign('/index.html');
};