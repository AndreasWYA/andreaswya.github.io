const highScoresList = document.getElementById('highScoresList');
const highGamesScores = JSON.parse(localStorage.getItem("highGamesScores")) || [];

highScoresList.innerHTML = highGamesScores
  .map(score => {
    return `<tr><li class="high-score"><td><span id="leaderboardName">${score.name}</span></td><td id="leaderboardScore">${score.score}</td></li></tr>`;
  })
  .join("");